﻿using System;

namespace OpenRec_2016
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("OpenRec 2016 - Open source RecNet server software.");
            new Server();
        }
    }
}
